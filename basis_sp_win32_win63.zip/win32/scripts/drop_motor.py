class Script:
    def __init__(self):
        pass
        
    def run(self):
        app.load_with_collisions('models/object/motor', mass=5.0, hpr=(0, 0, 0), pos=(-0.4, 0.2, 2.5))