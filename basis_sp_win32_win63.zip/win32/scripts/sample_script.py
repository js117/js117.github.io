class Script:
    def __init__(self):
        pass
    def run(self):
        robot=app.get_selected_robot()
        if robot:
            frames=[{'Base':-90.0, 'Shoulder':-45.0, 'Elbow Pitch': 45.0, 'Wrist Roll':90, 'time':5.0},
                    {'Wrist Pitch':60.0, 'txt':'Hello!', 'time':1.0},
                    {'Wrist Pitch':90.0, 'Elbow Pitch':65.0, 'time':1.0},
                    {'Wrist Pitch':60.0, 'Elbow Pitch':45.0, 'time':1.0},
                    {'Wrist Pitch':90.0, 'Elbow Pitch':65.0, 'time':1.0},
                    {'Base':0.0, 'Shoulder':0.0, 'Elbow Pitch': 0.0, 'Wrist Roll':0, 'time':5.0},
                    {'txt':'DONE!', 'time':1.0}]
            robot.play_frames(frames)        